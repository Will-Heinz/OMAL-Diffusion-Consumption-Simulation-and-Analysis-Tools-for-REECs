% wh_REEC_2D_DCconst models the 2D diffusion consumption kinetics in a 2D REEC
% It assumes a constant consumption rate across the entire chamber.
% Intial concentration, C0, is constant across the chamber.
% r1, r2 are the radii of the chamber. Note r1<r2. 
%       Default is r1 = 0.1, r2 = 1.0
% D is the iffusion constant. Default D = 0.01
% k is the constant consumption term. Default k = -10
% C0 is the initial concentration in the chamber. Default C0 = 177
% Cmax is the concentration in the upper chamber. Default Cmax = 177\
% tlist is the time list for time dependent slutions. Default tlist = [0:20]
%NEED TO FIGURE OUT UNITS

function [result,model] = OMAL_REEC_2D_DCconst(r1,r2,D,k,C0,Cmax,tlist)

%% set defaults
if isempty(r1)
    r1 = 0.1;
end

if isempty(r2)
    r2 = 1.0;
end

if isempty(D)
    D = 0.01;
end

if isempty(k)
    k=-10;
end

if isempty(C0)
    C0 = 177;
end
if isempty(Cmax)
    Cmax = 177;
end
if isempty(tlist)
    tlist = [0:20];
end
%% make the 2D chamber = 2 circles centered on 0,0
gd = [1,1;0,0;0,0;r1,r2];

%name them C1 and C2. Note: char([67,49]) = "C1".
ns = [67,67;49,50];

%define the set math that creates an annulus
sf = 'C2-C1';

%create the model object
model = createpde();

%create the gemoetry matrix
dl = decsg(gd,sf,ns);

%add it to the model
geometryFromEdges(model,dl);

%%display it
% figure
% pdegplot(model,'EdgeLabels','on')

%% set boundary conditions
% Dirichlet on the inner radius
applyBoundaryCondition(model,'dirichlet','Edge',[1,2,3,4],'h',1,'r',Cmax);

% Neuman on the outer edge
applyBoundaryCondition(model,'neumann','Edge',[5,6,7,8],'q',0,'g',0);

%% create the pde coefficients
% The PDE is (see f Coefficient for specifyCoefficients in docmentation)
% mu'' + du' - del(c del u) + au = f

fcoeffunction = @(location,state) k.* (1./(1+Cmax./state.u));

 specifyCoefficients(model,'m',0,'d',1,'c',D,'a',0,'f',fcoeffunction);

%% generate the mesh
generateMesh(model,'Hgrad',1.3,'GeometricOrder','linear');% added 'GeometricOrder','linear' on 9/9/19

%  figure
%  pdeplot(model);

%%set initial conditions
setInitialConditions(model,C0);

%% solve the time-dependent pde
result = solvepde(model,tlist);

  % plot the view from above
  figname = join(['k =',string(k)]);
  
%     pdeplot(model,'XYData',result.NodalSolution(:,numel(tlist)),'Title',figname);
end

% function f = fcoeffunction(location,state)
%     N = 1; % Number of equations
%     nr = length(location.x); % Number of columns
%     f = zeros(N,nr); % Allocate f
%     
%     %How to pass these constants into this function?
%     Cmax = 177; %this is a constant we need in this function.
%     k = -0.0018; %this is a constant we need in this function.
%     
%     % Now the particular functional form of f
%     f(1,:) = 1/(1 + Cmax/state.u);
% end
