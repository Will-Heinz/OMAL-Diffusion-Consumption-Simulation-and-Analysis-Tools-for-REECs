###

bigDir <- "/Users/flahertysj"


##Fill in info
nameList <- c("A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4")
rad.prof.folder <- "/Volumes/Sarah7TB/2020_02_11 3 day old Indo, AG, Control disks stained for Nos2Cox2Hif1a/Files for R/Radial Profile Plots/"
nuc.folder <- "/Volumes/Sarah7TB/2020_02_11 3 day old Indo, AG, Control disks stained for Nos2Cox2Hif1a/Files for R/Spot Statistics/"
um.per.pix <- 0.324
nos2.background <- 42.44708333
cox2.background <- 59.935
disk.size.list <- c(5300, 6900, 6600, 4800, 5850, 4800, 4200, 5900, 6500, 5000, 6900, 6600)
  
########Load in files



##Load in radial profile plots

rad.prof.list <- list.files(path = rad.prof.folder)
rad.prof.col.names <- c("pix", "hif", "nos", "cox", "dapi")

read.rad.profs <- function(file) {
  rad.prof.dataframe <- read.csv(file, col.names = rad.prof.col.names)
  return(rad.prof.dataframe)
}

setwd(rad.prof.folder)
rad.profs <- lapply(rad.prof.list, read.rad.profs)
setwd(bigDir)

names(rad.profs) <- nameList

##Load in nuclei distance statistics

nuc.d.list <- list.files(path = nuc.folder, pattern = "Distance_from_Origin_Reference_Frame.csv", recursive = TRUE)

read.nuc.distances <- function(file) {
  nuc.dist.dataframe <- read.csv(file, header = TRUE, skip = 3)
  return(nuc.dist.dataframe)
}

setwd(nuc.folder)
nuc.distances <- lapply(nuc.d.list, read.nuc.distances)
setwd(bigDir)

names(nuc.distances) <- nameList

# nuc.distances <- list()
# setwd(nuc.folder)
# i = 1
# for(nuc.dat in nuc.d.list){
#   nuc.distances[[i]] <- assign(toString(paste0("nuc.d.", nameList[i])), read.csv(nuc.dat, header = TRUE, skip = 3))
#   i = i + 1
# # }
# # setwd(bigDir)
# 
# names(nuc.distances) <- nameList


##Add distance/pixel columns to radial profile plots

#Make distance column
for(i in seq_along(rad.profs)){
  rad.profs[[i]]$distance.um <- rep(rad.profs[[i]]$pix * um.per.pix)
}

#Make pixel column
# for(j in seq_along(rad.profs)){
#   rad.profs[[j]]$pix <- rep(rad.profs[[j]]$distance.um / um.per.pix)
# }

##Subtract background signal from radial profile plots

#subtract nos2 background
for(i in seq_along(rad.profs)){
  rad.profs[[i]]$backsub.nos <- rep(rad.profs[[i]]$nos - nos2.background)
}

#subtract cox2 background
for(i in seq_along(rad.profs)){
  rad.profs[[i]]$backsub.cox <- rep(rad.profs[[i]]$cox - cox2.background)
}

##Set negative numbers = 0
for(i in seq_along(rad.profs)){
  rad.profs[[i]][rad.profs[[i]] < 0] <- 0
}

##Add normalized distance column to radial profile dataframes

for(i in seq_along(rad.profs)){
  rad.profs[[i]]$norm.d <- rep(rad.profs[[i]]$pix / disk.size.list[[i]])
}

#Also works:
# for(i in seq_along(rad.profs)){
#   rad.profs[[i]]$norm.d.um <- rep(rad.profs[[i]]$distance.um / rad.profs[[i]][disk.size.list[[i]], 6])
# }

##filter out normalized distance values greater than 1

filter <- function(file){
  filtered.file <- file[file$norm.d <= 1,]
  return(filtered.file)
}

filt.rad.profs <- lapply(rad.profs, filter)

##Add normalized distance column to nuclei statistics data frames

for(i in seq_along(nuc.distances)){
  nuc.distances[[i]]$norm.d <- rep(nuc.distances[[i]]$Distance.from.Origin.Reference.Frame /max(filt.rad.profs[[i]]$distance.um))
}

##filter out normalized distance values greater than 1

filt.nuc.distances <- lapply(nuc.distances, filter)

##bin the data

bin <- function(rad.file, nuc.file){
  results <- data.frame(
    "norm.d" = seq(0.025, 0.975, by = 0.05),
    "nos2" = c(tapply(rad.file$backsub.nos, cut(rad.file$norm.d, seq(0, 1, by = 0.05)), mean)),
    "cox2" = c(tapply(rad.file$backsub.cox, cut(rad.file$norm.d, seq(0, 1, by = 0.05)), mean)),
    "nuc.tally" = c(tapply(nuc.file$ID, cut(nuc.file$norm.d, seq(0, 1, by = 0.05)), length)),
    "min.pix.rad" = c(tapply(rad.file$pix, cut(rad.file$norm.d, seq(0, 1, by = 0.05)), min)),
    "max.pix.rad" = c(tapply(rad.file$pix, cut(rad.file$norm.d, seq(0, 1, by = 0.05)), max))
  )
  results$bin.area <- c( (pi*(results$max.pix.rad)^2) - (pi*(results$min.pix.rad)^2))
  results$nuc.per.pix <- results$nuc.tally / results$bin.area
  results$nos2.per.cell <- results$nos2 / results$nuc.per.pix
  results$cox2.per.cell <- results$cox2 / results$nuc.per.pix
  
  return(results)
}

binned.results <- list()
for(i in seq_along(filt.rad.profs)){
  binned.results[[i]] <- bin(filt.rad.profs[[i]], filt.nuc.distances[[i]])
}
names(binned.results) <- nameList


##Make dataframes for easy copy/paste into R

nos2.results <- data.frame(
  "A1" <- binned.results[[nameList[1]]]$nos2,
  "A2" <- binned.results[[nameList[2]]]$nos2,
  "A3" <- binned.results[[nameList[3]]]$nos2,
  "A4" <- binned.results[[nameList[4]]]$nos2,
  "B1" <- binned.results[[nameList[5]]]$nos2,
  "B2" <- binned.results[[nameList[6]]]$nos2,
  "B3" <- binned.results[[nameList[7]]]$nos2,
  "B4" <- binned.results[[nameList[8]]]$nos2,
  "C1" <- binned.results[[nameList[9]]]$nos2,
  "C2" <- binned.results[[nameList[10]]]$nos2,
  "C3" <- binned.results[[nameList[11]]]$nos2,
  "C4" <- binned.results[[nameList[12]]]$nos2
)
colnames(nos2.results) <- nameList


cox2.results <- data.frame(
  "A1" <- binned.results[[nameList[1]]]$cox2,
  "A2" <- binned.results[[nameList[2]]]$cox2,
  "A3" <- binned.results[[nameList[3]]]$cox2,
  "A4" <- binned.results[[nameList[4]]]$cox2,
  "B1" <- binned.results[[nameList[5]]]$cox2,
  "B2" <- binned.results[[nameList[6]]]$cox2,
  "B3" <- binned.results[[nameList[7]]]$cox2,
  "B4" <- binned.results[[nameList[8]]]$cox2,
  "C1" <- binned.results[[nameList[9]]]$cox2,
  "C2" <- binned.results[[nameList[10]]]$cox2,
  "C3" <- binned.results[[nameList[11]]]$cox2,
  "C4" <- binned.results[[nameList[12]]]$cox2
)
colnames(cox2.results) <- nameList

nos2.per.cell.results <- data.frame(
  "A1" <- binned.results[[nameList[1]]]$nos2.per.cell,
  "A2" <- binned.results[[nameList[2]]]$nos2.per.cell,
  "A3" <- binned.results[[nameList[3]]]$nos2.per.cell,
  "A4" <- binned.results[[nameList[4]]]$nos2.per.cell,
  "B1" <- binned.results[[nameList[5]]]$nos2.per.cell,
  "B2" <- binned.results[[nameList[6]]]$nos2.per.cell,
  "B3" <- binned.results[[nameList[7]]]$nos2.per.cell,
  "B4" <- binned.results[[nameList[8]]]$nos2.per.cell,
  "C1" <- binned.results[[nameList[9]]]$nos2.per.cell,
  "C2" <- binned.results[[nameList[10]]]$nos2.per.cell,
  "C3" <- binned.results[[nameList[11]]]$nos2.per.cell,
  "C4" <- binned.results[[nameList[12]]]$nos2.per.cell
)
colnames(nos2.per.cell.results) <- nameList

cox2.per.cell.results <- data.frame(
  "A1" <- binned.results[[nameList[1]]]$cox2.per.cell,
  "A2" <- binned.results[[nameList[2]]]$cox2.per.cell,
  "A3" <- binned.results[[nameList[3]]]$cox2.per.cell,
  "A4" <- binned.results[[nameList[4]]]$cox2.per.cell,
  "B1" <- binned.results[[nameList[5]]]$cox2.per.cell,
  "B2" <- binned.results[[nameList[6]]]$cox2.per.cell,
  "B3" <- binned.results[[nameList[7]]]$cox2.per.cell,
  "B4" <- binned.results[[nameList[8]]]$cox2.per.cell,
  "C1" <- binned.results[[nameList[9]]]$cox2.per.cell,
  "C2" <- binned.results[[nameList[10]]]$cox2.per.cell,
  "C3" <- binned.results[[nameList[11]]]$cox2.per.cell,
  "C4" <- binned.results[[nameList[12]]]$cox2.per.cell
)
colnames(cox2.per.cell.results) <- nameList
