function [result binResult] = OMAL_spheroid_I_vs_depth(pixSize)

%set a default pixel size
if nargin < 1
    %from Leica image: 031219 Coculture Spheroids Control 2.lif and 
    %MIP: MAX_031219 Coculture Spheroids Control 2 MIP.tif
    pixSize = 0.5681818;
    
    %for Nos2/Cox2 spheroids 2020_04_09 data analysis
    %analysis is MIP of Confocal z-stacks from Leica SP8.
    pixSize = 0.568;
end
    
%% load an image file
%ask for a file
theFileSpec = omal_uigetfile();
%get the parts
[fp fn fe] = fileparts(theFileSpec);

%get file info
info = imfinfo(theFileSpec);
szInfo = size(info);

%how many channels?
%nCh = szInfo(1);
nCh = 2; % only use first 2 channels 

%get image dimesnsions
height = info(1).Height;
width = info(1).Width;

%create array for image
%theImage = zeros(height,width,nCh);

%for idx = 1:nCh
    g = imread(theFileSpec,1);
    imagesc(g);
    axis image;
    colorbar;
    theImage = g;
    r = imread(theFileSpec,2);
    imagesc(r);
    axis image;
    colorbar;
    theImage(:,:,2) = r;
    
    %theImage(:,:,1) = theChannel;
%end

%% segment it based on the first channel
%segment the image (hardwired thresholds based on data set)
%for 4t1 and ANA spheroids
% [BW,maskedImage] = omal_simple_segmentImage_manual(theImage(theImage(:,:,1)); %for control
% [BW,maskedImage] = omal_simple_segmentImage_manual(theImage(theImage(:,:,1),10000); %for IFN+LPS

%for Nos2/Cox2 spheroids 
[BW,maskedImage] = omal_simple_segmentImage_manual(theImage(:,:,1),6425); %for Cox2

%get the largest object
BW_out = bwareafilt(BW, 1);

% Fill holes in regions.
BW_out = imfill(BW_out, 'holes');

%display the segmented image

[fbin abin] = omal_setup_figure();
imagesc(abin, BW_out);
axis image;
colorbar;


%make a title
titleStr = strjoin({'Mask_',strcat(fn,fe)});
title(abin,titleStr, 'Interpreter', 'none');

%save the figure
theFileName = fullfile(fp,strcat(fn,'_Mask'));
omal_save_fig(fbin,theFileName)

%% get the distance map within the spheroid to its bondary
dBW = bwdist(~BW_out);

%display the distance map
[fdist adist] = omal_setup_figure();
imagesc(adist, dBW);
axis image;
colorbar;

%make a title
titleStr = strjoin({'DistMap_',strcat(fn,fe)});
title(adist,titleStr, 'Interpreter', 'none');

%save the figure
theFileName = fullfile(fp,strcat(fn,'_DistMap'));
omal_save_fig(fdist,theFileName)

%define points within the spheroid as distances > 0
interior = dBW > 0;

%make an array to hold raw results amd ascale the distances
distances = dBW(interior)*pixSize;
result = zeros(length(distances),nCh+1);
result(:,1) = distances;
for i = 2:nCh+1
    thisChannel = squeeze(theImage(:,:,i-1));
    result(:,i) = thisChannel(interior);
end

%% average the resuls by micron distance
%get the max distance
maxd = ceil(max(distances,[],'all'));

%histogram the distances
% binEdges = [0:maxd];
% nBins = length(binEdges) - 1;
% [N edges bin] = histcounts(distances,binEdges);

binLimits = [0,maxd];
binWidth = 1; %microns!
[N edges bin] = histcounts(distances,'BinLimits',binLimits,'BinWidth',binWidth);
nBins = length(edges) -1;

%make an array to hold the results
binResult = zeros(nBins,nCh+1);
binResult(:,1) = edges(2:end);

%loop through the bins and average each channel's intensity
for thisBin = 1:nBins
        %find the array indicies for this bin
        binIndex = (bin == thisBin);
    for thisCh = 2:nCh+1
        binResult(thisBin,thisCh) = mean(result(binIndex,thisCh));
    end
end

%% get filename parts for plots
[fp fn fe] = fileparts(theFileSpec);

%% plot raw intensities v distance in a figure
f1 = figure();
ax1 = axes(f1);

plot(ax1,distances,result(:,2),'b.');
hold on
plot(ax1,distances,result(:,3),'r.');
title(strcat('Raw data: ',fn));
hold off

%% plot binned results
f2 = figure();
ax2 = axes(f2);

plot(ax2,binResult(:,1),binResult(:,2),'b.');
hold on
plot(ax2,binResult(:,1),binResult(:,3),'r.');
title(strcat('Binned data: ',fn));
hold off

%% plot normalized binned results
f3 = figure();
ax3 = axes(f3);
maxCh1 = max(binResult(:,2),[],'all');
maxCh2 = max(binResult(:,3),[],'all');

plot(ax3,binResult(:,1),binResult(:,2)/maxCh1,'b.');
hold on
plot(ax3,binResult(:,1),binResult(:,3)/maxCh2,'r.');
title(strcat('Normalized binned data: ',fn));
hold off

normResult = binResult;
normResult(:,2) = binResult(:,2)/maxCh1;
normResult(:,3) = binResult(:,3)/maxCh2;

%% export the results
tRaw = array2table(result,'VariableNames',{'Distance','Ch1','Ch2'});
tBinned = array2table(binResult,'VariableNames',{'Distance','Ch1','Ch2'});
tNorm = array2table(normResult,'VariableNames',{'Distance','Ch1','Ch2'});

%make a filename
[fp fn fe] = fileparts(theFileSpec);
outfileRaw = fullfile(fp,strcat(fn,'_RawResult.csv'));
outfileBinned = fullfile(fp,strcat(fn,'_BinnedResult.csv'));
outfileNorm = fullfile(fp,strcat(fn,'_NormBinnedResult.csv'));
writetable(tRaw,outfileRaw);
writetable(tBinned,outfileBinned);
writetable(tNorm,outfileNorm);

end

%% Helper functions

%% save the figure as a .fig file and as a .tif and .pdf file
function omal_save_fig(theFigure,theFileName)
    %keep the background color the same as on the screen
    theFigure.InvertHardcopy = 'off';
    
    %make the filenames
    figFile = strcat(theFileName,'.fig');
    tifFile = strcat(theFileName,'.tif');
    pdfFile = strcat(theFileName,'.pdf');
    
    %save ths fig file
    saveas(theFigure,figFile);
    
    %save ths tif file
    saveas(theFigure,tifFile);
    
    %save ths pdf file
    saveas(theFigure,pdfFile);
end


function [f a] = omal_setup_figure()
%simple code to make a figure with axes object

%colors
colorStr = ['r','k','b','c','m','y','g'];

% fonts and display parameters for the plots
theFontSize = 18; %this is for xylabels
theNumberFontSize = 18; %this is for the numbers on the axes

%white background
f = figure('Color','w');

a = axes(f, 'FontSize',theNumberFontSize);

end

function theFileSpec = omal_uigetfile()
    % this file launches the select file dialog, then prints the full path
    % specification to the file in the command window.
    % To use type the following on the command line:
    % theFileSpec = omal_uigetfile();
    
% Copyright (C) 2020, Will Heinz
% Optical Microscopy and Analysis Laboratory
% Cancer Research Technology Program
% Frederick National Laboratory for Cancer Research
% National Cancer Institute

   % ask the user for the file
   [file,path] = uigetfile('*.*','Select a file');

   %build the full specification
   theFileSpec = fullfile(path,file);
   
   %display it in the command window.
   display(theFileSpec);
end

function [BW,maskedImage] = omal_simple_segmentImage_manual(X,thresh)
%segmentImage Segment image using auto-generated code from imageSegmenter app
%  [BW,MASKEDIMAGE] = segmentImage(X) segments image X using auto-generated
%  code from the imageSegmenter app. The final segmentation is returned in
%  BW, and a masked image is returned in MASKEDIMAGE.

% Auto-generated by imageSegmenter app on 26-Mar-2020
%----------------------------------------------------


% Adjust data to span data range.
X = imadjust(X);

% Threshold image - manual threshold
BW = X > thresh;

% Create masked image.
maskedImage = X;
maskedImage(~BW) = 0;
end

