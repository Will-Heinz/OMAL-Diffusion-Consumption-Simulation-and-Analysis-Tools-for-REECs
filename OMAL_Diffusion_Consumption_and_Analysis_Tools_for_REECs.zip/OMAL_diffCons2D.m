%%OMAL_diffCons2D solves a 2D PDE model of a REEC.
% 
% All variables are hardwired for now.
% The following variables define the model

function result = OMAL_diffCons2D()
result = 0;

%hardwire output folder
outputdir = '~/Desktop/Results/';
%hardwire results file
resultsFile = 'Results';

olddir = cd(outputdir);

%Set a value  for convergence of time course.
%This is defined as an RMS difference between successive time points
convergeLimit = 0.001;

%% set variables for PDE
% use microns and seconds as primary units
r1 = 350;           %um
r2 = 6000;            %um
D = 3370;            %um2/s

C0 = 178.0;                 %uM
Cmax = C0;                  %uM
hoursmax = 48;              %max run time
tmax = hoursmax * 3600;     % 3600 s/h
tlist = [0:tmax];
displaydt = 1800;           % time step for display in s
displaytmax = 4.5*3600; %maximum display time
fig_visibile = 'on';

%cell max consumption rate
Amax = 1e13.* fliplr([0.968,2.98]); %moleculess/cell/s Frees, et al. 2014 scaled by 10^6

%celldiameter%
%diaC = [10 20 30]; %um Use a vector for multiple diameters.
diaC = [13.5]; %um

Navogadro = 6.0221409e+23;


%% set variables for plotting
Nx = 20;
xq = [r1:(r2-r1)/Nx:r2];
yq = zeros([1,numel(xq)]);

timepoints = tlist(1:displaydt:displaytmax);

%create arrays for results for table
ntp = numel(Amax)*numel(diaC);
nAmax = numel(Amax);
ndiaC = numel(diaC);

Radius1 = zeros([nAmax,ndiaC]);
Radius1(:) = r1;

Radius2 = zeros([nAmax,ndiaC]);
Radius2(:) = r2;

DiffConst = zeros([nAmax,ndiaC]);
DiffConst(:) = D;
Conc0 = zeros([nAmax,ndiaC]);
Conc0(:)=C0;

ConcMax = zeros([nAmax,ndiaC]);
ConcMax(:)=Cmax;

ConcMin = zeros([nAmax,ndiaC]);

TotalHours = zeros([nAmax,ndiaC]);
TotalHours(:) = hoursmax;

DisplayTStep  = zeros([nAmax,ndiaC]);
DisplayTStep(:) = displaydt;

Amx = zeros([nAmax,ndiaC]); 
Nc = zeros([nAmax,ndiaC]);
k_calc = zeros([nAmax,ndiaC]);
niche_calc = zeros([nAmax,ndiaC]);
niche_fit = zeros([nAmax,ndiaC]);
convTime = zeros([nAmax,ndiaC]);

%% Loop over Amax and diaC
%iterate a results index for the results arrays
Rindex = 1;

%make some summary figures for later
legendNames = string(Amax*1e-11);
fniche_fit = figure('Name','Niche (fit)','Visible','Off');
fniche_calc = figure('Name','Niche (calc)','Visible','Off');
fniche_v_niche = figure('Name','Niche correlation','Visible','Off');
fconvTime = figure('Name','Convergence time','Visible','Off');
fConcMin = figure('Name','Minimum Concentration','Visible','Off');

%Do the simulation for each Amax and diameter
for Aindex = 1:numel(Amax)
    for Dindex = 1:numel(diaC)
        display(strjoin(['Amax =',string(Amax(Aindex)*1e-11),'Dia = ',string(diaC(Dindex))]));
        
        %cell density
        Ncells = 1.0/diaC(Dindex)^3;  %1/um^3
        
        %consumption rate
        k = -(Amax(Aindex))*Ncells/(Cmax * Navogadro* 1e-15); %

        %niche calcualted
        niche = sqrt(D/(-k));
        
        %do the model
        [result,model] = OMAL_REEC_2D_DCconst(r1,r2,D,k,C0,Cmax,tlist);

        % plot the results
        figname = strjoin(['Amax =',string(Amax(Aindex)*1e-11),' diam =',string(diaC(Dindex)),'k =',string(k)]);

        %plot 2D version
        initialName = strjoin(['Initial state',figname],'');
        figure('Name',initialName,'Visible','Off');
        pdeplot(model,'XYData',result.NodalSolution(:,1));
        xlabel('X (�m)');
        ylabel('Y (�m)');
        saveas(gcf,strjoin([initialName,'.png'],''));
        close;
        
        steadyStateName = strjoin(['Steady state',figname]);
        figure('Name',steadyStateName,'Visible','Off');
        pdeplot(model,'XYData',result.NodalSolution(:,tmax));
        xlabel('X (�m)');
        ylabel('Y (�m)');
        saveas(gcf,strjoin([steadyStateName,'.png'],''));
        close;
        
        steadyState3DName = strjoin(['Steady state 3D',figname]);
        figure('Name',steadyState3DName,'Visible','Off');
        pdeplot(model,'XYData',result.NodalSolution(:,tmax),'ZData',result.NodalSolution(:,tmax));
        xlabel('X (�m)');
        ylabel('Y (�m)');
        zlabel('Concentration (�M)');
        saveas(gcf,strjoin([steadyState3DName,'.png'],''));
        close;

        %plot the C(r) for each time point
        timeName = strjoin(['Time course',figname],'');
        figure('Name',timeName,'Visible',fig_visibile);
        
        %reset the convergence time
        convergeTime = timepoints(numel(timepoints));
        convergedFlag = 0;
        
        for tindex = 1:numel(timepoints)
            %timelyResult = result.NodalSolution(:,tindex);
            cofr = interpolateSolution(result,xq,yq,1 + timepoints(tindex));
            plot(xq,cofr);
            hold on
         
            %calculate rms between this plot and the previous one and set
            %convergence time
            
            
            if (tindex > 1) & not(convergedFlag)
                sumRMSdiff = sum(sqrt(mean((cofr(1:Nx-1) - oldcofr(1:Nx-1)).^2)));
                normRMS = sumRMSdiff/Cmax;
                
                if normRMS < convergeLimit
                    convergeTime = min([convergeTime,timepoints(tindex)]);
                    convergedFlag = 1;
                    display(strjoin(['converged at',string(convergeTime)]));
                end
            end
            
            %save the current one for later
            oldcofr = cofr;                          
        end
        legend_time_course = string(timepoints/3600);
        tcl = legend(legend_time_course);
        title(tcl,'hours');
        hold off
        
        xlabel('Radial distance (�m)');
        ylabel('Concentration (�M)');
                
        saveas(gcf,strjoin([timeName,'.png'],''));
        savefig(strjoin([timeName,'.fig'],''))
        close;
        
           
        %fit the eponential
        xdata = xq(1:Nx-1);
        ydata = reshape(cofr(1:Nx-1),size(xdata));
        
        %guess for coefficients
        x0 = [max(ydata),1/niche,min(ydata)];
        
        %do the fit
        bestx = OMAL_expfit(xdata,ydata,x0);
        Aexp = bestx(1);
        lambdaexp = bestx(2);
        y0=bestx(3);
        yfit = Aexp*exp(-lambdaexp*xdata)+y0;
        
        %plot the last curve and fit it to an exponential
        fitName =  strjoin(['Exp. fit',figname],'');
        figure('Name',fitName,'Visible','Off');
        plot(xdata,ydata,'*');
        hold on
        plot(xdata,yfit,'r');
        saveas(gcf,strjoin([fitName,'.png'],''));
        close
        
        %load up the arrays
        Amx(Aindex,Dindex) = Amax(Aindex); 
        Nc(Aindex,Dindex) = Ncells;
        k_calc(Aindex,Dindex) = k;
        niche_calc(Aindex,Dindex) = niche;
        niche_fit(Aindex,Dindex) = 1/lambdaexp;
        convTime(Aindex,Dindex) = convergeTime;
        ConcMin(Aindex,Dindex) = min(ydata,[],'all');
 end
end

%% Display and save results
%next loop over the results and plot lines for each Amax
% linecolors = ['k','r','b','g','m','c','y'];
% nlc = numel(linecolors);

for Aindex = 1:numel(Amax)
    figure(fniche_calc);
    plot(diaC, niche_calc(Aindex,:));
    hold on
       
    figure(fniche_fit);
    plot(diaC, niche_fit(Aindex,:));
    hold on
       
    figure(fniche_v_niche);
    plot(niche_calc(Aindex,:), niche_fit(Aindex,:),'*');
    hold on
        
    figure(fconvTime);
    plot(diaC, convTime(Aindex,:)/3600);
    hold on
        
    figure(fConcMin);
    plot(diaC, ConcMin(Aindex,:));
    hold on
           
end

%addlegends to these plots and save these plots
legendNames = string(Amax*1e-11);
legendTitle = 'pMol/min/10^5 cells';

figure(fniche_calc);
title('Niche size (steady state) vs cell diameter and consumption rate');
xlabel('Cell diameter (�m)');
ylabel('Niche size (�m)');
lniche_calc = legend(legendNames);
title(lniche_calc,legendTitle);
saveas(gcf,strjoin({'Summary Niche size calculated','.png'},''));
close

figure(fniche_fit);
title('Niche size (pde) vs cell diameter and consumption rate');
xlabel('Cell diameter (�m)');
ylabel('Niche size (�m)');
lniche_fit = legend(legendNames);
title(lniche_fit,legendTitle);
saveas(gcf,strjoin({'Summary Niche size fit','.png'},''));
close

figure(fniche_v_niche);
title('Niche size (steady state) vs niche size (pde)');
xlabel('Steady state niche size (�m)');
ylabel('PDE niche size (�m)');
lniche_v_niche = legend(legendNames);
title(lniche_v_niche,legendTitle);
saveas(gcf,strjoin({'Summary Niche v niche','.png'},''));
close

figure(fconvTime);
title('Convergence time vs cell diameter and consumption rate');
xlabel('Cell diameter (�m)');
ylabel('Convergence time (h)');
lconvTime = legend(legendNames);
title(lconvTime,legendTitle);
saveas(gcf,strjoin({'Summary convergence','.png'},''));
close

figure(fConcMin);
title('Minimum concentration vs cell diameter and consumption rate');
xlabel('Cell diameter (�m)');
ylabel('Concentration (�M)');
lConcMin = legend(legendNames);
title(lConcMin,legendTitle);
saveas(gcf,strjoin({'Summary Concentration minimum','.png'},''));
close

%package the reaults as a structure
theResult = struct( ...
    'r1',Radius1, ...
    'r2',Radius2, ...
    'D',DiffConst, ...
    'C0',Conc0, ...
    'Cmax',ConcMax, ...
    'Cmin',ConcMin, ...
    'TotalHours',TotalHours, ...
    'Amax',Amx, ...
    'Nc',Nc, ...
    'k',k_calc, ...
    'nicheCalc',niche_calc, ...
    'nicheFit',niche_fit, ...
    'tau',convTime);


% writetable(results_table,resultsFile);
% %write the results as csv files
Radius1 = Radius1';
writematrix(Radius1);

Radius2 = Radius2';
writematrix(Radius2);

DiffConst = DiffConst';
writematrix(DiffConst);

Conc0 = Conc0';
writematrix(Conc0);

ConcMax = ConcMax';
writematrix(ConcMax);

ConcMin = ConcMin';
writematrix(ConcMin);

TotalHours = TotalHours';
writematrix(TotalHours);

DisplayTStep = DisplayTStep';
writematrix(DisplayTStep);


Amax = Amx';
writematrix(Amax);

Nc = Nc';
writematrix(Nc);

k_calc = k_calc';
writematrix(k_calc);

niche_calc = niche_calc';
writematrix(niche_calc);

niche_fit = niche_fit';
writematrix(niche_fit);

convTime = convTime';
writematrix(convTime);

%% CSV output
%put the results in a table and save as a csv file
%results_table = table(Radius1,Radius2,DiffConst,Conc0,ConcMax,ConcMin,TotalHours,DisplayTStep,Amx,Nc,k_calc,niche_calc,niche_fit,convTime);
%writetable(results_table,resultsFile);

close all;

    %export this function
    thisfunc = fileread(strcat(mfilename('fullpath'),'.m'));
    mfile_fn = strjoin(string([outputdir,'/Code_used_','.txt']),'');
    eFileID = fopen(mfile_fn,'w');
    fprintf(eFileID,'%s',thisfunc);
    fclose(eFileID);
    
result =theResult;

end

%% Fitting helper function
function result =OMAL_expfit(t,y,x0)
%rng default % for reproducibility
%   t = 2:0.1:12;
%   y = 40*exp(-0.5*t) + randn(size(t))+ 10.0;

figure
plot(t,y,'*');
hold on

 fun = @(x)omal_sseval_exp(x,t,y);
        %x0 = rand(3,1);
        bestx = fminsearch(fun,x0)
        Aexp = bestx(1);
        lambdaexp = bestx(2);
        y0 = bestx(3);
        yfit = Aexp*exp(-lambdaexp*t)+y0;
      
        plot(t,yfit,'r');
        hold off
        close
   result = bestx;
end


function result = omal_sseval_exp(x,tdata,ydata)
A = x(1);
lambda = x(2);
y0=x(3);
result = sum((ydata - A*exp(-lambda*tdata)-y0).^2);
end